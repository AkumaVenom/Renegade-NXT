#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RenegadeHarvestPoint.generated.h"

class USceneComponent;
class USphereComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeHarvestReservationSignature, AActor*, Harvester);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRenegadeHarvestDepletedSignature);

UCLASS(BlueprintType, Blueprintable)
class RENEGADEVEHICLEAI_API ARenegadeHarvestPoint : public AActor
{
    GENERATED_BODY()

public:
    ARenegadeHarvestPoint();

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Harvest")
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Harvest")
    TObjectPtr<USphereComponent> InteractionVolume;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest")
    FName HarvestGroup = NAME_None;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest")
    TArray<int32> AllowedTeamIds;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest")
    bool bExclusiveReservation = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest")
    bool bInfiniteResource = true;

    UPROPERTY(Replicated, EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest", meta = (EditCondition = "!bInfiniteResource", ClampMin = "0.0"))
    float AvailableResource = 5000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvest", meta = (ClampMin = "0.01"))
    float ExtractionRateMultiplier = 1.0f;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Harvest")
    TObjectPtr<AActor> ReservedBy = nullptr;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvest")
    FRenegadeHarvestReservationSignature OnReserved;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvest")
    FRenegadeHarvestReservationSignature OnReservationReleased;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvest")
    FRenegadeHarvestDepletedSignature OnDepleted;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Harvest")
    bool IsTeamAllowed(int32 TeamId) const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Harvest")
    bool IsAvailableFor(AActor* Harvester) const;

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvest")
    bool TryReserve(AActor* Harvester);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvest")
    void ReleaseReservation(AActor* Harvester);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvest")
    float ExtractResource(float RequestedAmount);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Harvest")
    float GetInteractionRadius() const;
};
