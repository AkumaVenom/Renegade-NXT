#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Engine/EngineTypes.h"
#include "RenegadeVehicleAITypes.h"
#include "RenegadeVehicleDriverComponent.generated.h"

class AActor;
class ARenegadeVehicleSplinePath;
class UChaosVehicleMovementComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRenegadeVehicleDriveStateChangedSignature, ERenegadeVehicleDriveState, PreviousState, ERenegadeVehicleDriveState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeVehicleRouteCompletedSignature, ARenegadeVehicleSplinePath*, CompletedPath);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeVehicleTargetChangedSignature, AActor*, NewTarget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRenegadeVehicleFireRequestSignature, AActor*, TargetActor, FVector, AimLocation);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRenegadeVehicleWorldTargetReachedSignature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeVehicleDriverFaultSignature, FString, Message);

UCLASS(ClassGroup = (Renegade), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class RENEGADEVEHICLEAI_API URenegadeVehicleDriverComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    URenegadeVehicleDriverComponent();

    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Identity")
    int32 TeamId = INDEX_NONE;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Startup")
    bool bAutoStart = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Startup")
    TObjectPtr<ARenegadeVehicleSplinePath> AutoStartPath = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Startup")
    ERenegadeVehicleRouteDirection AutoStartDirection = ERenegadeVehicleRouteDirection::Forward;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Startup")
    bool bAutoStartUseReverseGear = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Startup")
    bool bAllowInputsWithoutController = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "100.0", Units = "cm"))
    float LookAheadDistance = 950.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "50.0", Units = "cm"))
    float MinimumLookAheadDistance = 350.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "25.0", Units = "cm"))
    float RouteEndTolerance = 260.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "100.0", Units = "cm"))
    float EndBrakingDistance = 1200.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (Units = "cm"))
    float LaneOffset = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    bool bPreserveProgressWhenResuming = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "0.0", Units = "cm"))
    float MaximumResumeBacktrack = 1000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "1.0", Units = "km/h"))
    float CruiseSpeedKPH = 42.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "1.0", Units = "km/h"))
    float TurnSpeedKPH = 20.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "1.0", Units = "km/h"))
    float CombatSpeedKPH = 24.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float MaximumThrottleInput = 0.9f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float MaximumBrakeInput = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Speed", meta = (ClampMin = "0.001"))
    float SpeedControlGain = 0.045f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Steering", meta = (ClampMin = "5.0", ClampMax = "180.0", Units = "deg"))
    float FullSteeringAngleDegrees = 55.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Steering", meta = (ClampMin = "0.1"))
    float SteeringGain = 1.25f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Steering", meta = (ClampMin = "1.0", ClampMax = "180.0", Units = "deg"))
    float SlowTurnAngleDegrees = 38.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance")
    bool bEnableObstacleAvoidance = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance", meta = (ClampMin = "100.0", Units = "cm"))
    float ObstacleProbeDistance = 1300.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance", meta = (ClampMin = "10.0", Units = "cm"))
    float ObstacleProbeRadius = 120.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance", meta = (ClampMin = "0.0", Units = "cm"))
    float ObstacleProbeHeight = 80.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance", meta = (ClampMin = "1.0", ClampMax = "80.0", Units = "deg"))
    float SideProbeAngleDegrees = 28.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance", meta = (ClampMin = "0.0", ClampMax = "2.0"))
    float ObstacleSteeringWeight = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Obstacle Avoidance")
    TEnumAsByte<ECollisionChannel> ObstacleTraceChannel = ECC_Visibility;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Stuck Recovery")
    bool bEnableStuckRecovery = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Stuck Recovery", meta = (ClampMin = "0.0", Units = "km/h"))
    float StuckSpeedThresholdKPH = 1.5f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Stuck Recovery", meta = (ClampMin = "0.25", Units = "s"))
    float StuckDetectionTime = 3.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Stuck Recovery", meta = (ClampMin = "0.1", Units = "s"))
    float RecoveryReverseTime = 1.4f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Stuck Recovery", meta = (ClampMin = "0.1", Units = "s"))
    float RecoveryForwardTime = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat")
    bool bEnableCombatManeuvering = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat")
    ERenegadeVehicleCombatManeuver CombatManeuver = ERenegadeVehicleCombatManeuver::DynamicStandoff;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "100.0", Units = "cm"))
    float PreferredCombatDistance = 2200.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "0.0", Units = "cm"))
    float MinimumCombatDistance = 1000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "100.0", Units = "cm"))
    float MaximumCombatDistance = 4200.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "1.0", ClampMax = "170.0", Units = "deg"))
    float CombatOrbitAdvanceDegrees = 55.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "0.1", Units = "s"))
    float CombatReplanInterval = 1.5f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "0.05", Units = "s"))
    float FireRequestInterval = 0.18f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat", meta = (ClampMin = "0.0", Units = "s"))
    float DefaultCombatResumeDelay = 0.75f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Combat")
    bool bResumeRouteAfterCombat = true;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime")
    ERenegadeVehicleDriveState DriveState = ERenegadeVehicleDriveState::Idle;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime")
    TObjectPtr<ARenegadeVehicleSplinePath> AssignedPath = nullptr;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime", meta = (Units = "cm"))
    float CurrentDistanceAlongSpline = 0.0f;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime")
    ERenegadeVehicleRouteDirection TravelDirection = ERenegadeVehicleRouteDirection::Forward;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime")
    bool bDriveAssignedRouteInReverseGear = false;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Runtime")
    TObjectPtr<AActor> CombatTarget = nullptr;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleDriveStateChangedSignature OnDriveStateChanged;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleRouteCompletedSignature OnRouteCompleted;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleTargetChangedSignature OnCombatTargetChanged;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleFireRequestSignature OnFireRequested;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleWorldTargetReachedSignature OnWorldTargetReached;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Events")
    FRenegadeVehicleDriverFaultSignature OnDriverFault;

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Route", meta = (DisplayName = "Start Following Vehicle Path"))
    bool StartFollowing(ARenegadeVehicleSplinePath* Path, bool bReacquireFromCurrentLocation = true, ERenegadeVehicleRouteDirection Direction = ERenegadeVehicleRouteDirection::Forward, bool bUseReverseGear = false);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Route")
    void StopDriving(bool bClearAssignedPath = true, bool bApplyBrake = true);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Route")
    bool ResumeFollowing();

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Combat", meta = (AdvancedDisplay = "ResumeDelayOverride"))
    void SetCombatActive(bool bCombatActive, AActor* NewCombatTarget = nullptr, float ResumeDelayOverride = -1.0f);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Movement")
    bool SetWorldMoveTarget(FVector WorldTarget, float DesiredSpeedKPH = 12.0f, float AcceptanceRadius = 250.0f);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Movement")
    void ClearWorldMoveTarget(bool bApplyBrake = true);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Movement")
    void SetDrivingEnabled(bool bEnabled);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Runtime")
    UChaosVehicleMovementComponent* GetVehicleMovementComponent() const { return VehicleMovement; }

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Runtime")
    float GetForwardSpeedKPH() const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Runtime")
    bool IsInCombatMovement() const;

private:
    UPROPERTY(Transient)
    TObjectPtr<UChaosVehicleMovementComponent> VehicleMovement = nullptr;

    FVector WorldMoveTarget = FVector::ZeroVector;
    FVector CombatDestination = FVector::ZeroVector;

    float WorldMoveDesiredSpeedKPH = 12.0f;
    float WorldMoveAcceptanceRadius = 250.0f;
    float ResumeCountdown = 0.0f;
    float CombatReplanCountdown = 0.0f;
    float FireRequestCountdown = 0.0f;
    float StuckAccumulator = 0.0f;
    float RecoveryPhaseTime = 0.0f;
    float RecoverySteeringSign = 1.0f;
    int32 RecoveryPhase = 0;
    int32 CombatOrbitSign = 1;
    bool bHadRouteBeforeCombat = false;

    ERenegadeVehicleDriveState StateBeforeRecovery = ERenegadeVehicleDriveState::Idle;
    ERenegadeVehicleDriveState StateBeforeCombat = ERenegadeVehicleDriveState::Idle;
    ERenegadeVehicleDriveState PendingResumeState = ERenegadeVehicleDriveState::Idle;

    float LastThrottleCommand = 0.0f;
    float LastBrakeCommand = 0.0f;
    float LastSteeringCommand = 0.0f;

    bool ResolveVehicleMovement();
    bool HasAuthorityToDrive() const;
    void SetDriveState(ERenegadeVehicleDriveState NewState);
    void ApplyStopInputs(bool bApplyBrake);
    void UpdateRouteDriving(float DeltaTime);
    void UpdateCombatDriving(float DeltaTime);
    void UpdateCombatPaused(float DeltaTime);
    void UpdateWorldTargetDriving(float DeltaTime);
    void UpdateWaitingToResume(float DeltaTime);
    void UpdateStuckRecovery(float DeltaTime);
    void UpdateStuckDetection(float DeltaTime);
    void CompleteRoute();
    void ReplanCombatDestination();
    float GetStableRouteDistance(float ClosestDistance) const;
    float GetRemainingRouteDistance() const;
    FVector GetRouteLookAheadTarget(float RemainingDistance) const;
    void DriveTowardPoint(const FVector& TargetPoint, float DesiredSpeedKPH, float DeltaTime, bool bReverseGear = false, float DistanceForBraking = -1.0f);
    void CalculateObstacleAvoidance(bool bReverseProbe, float& OutSteeringBias, float& OutSpeedScale) const;
    float ProbeObstacleAtYaw(float YawDegrees, bool bReverseProbe) const;
};
