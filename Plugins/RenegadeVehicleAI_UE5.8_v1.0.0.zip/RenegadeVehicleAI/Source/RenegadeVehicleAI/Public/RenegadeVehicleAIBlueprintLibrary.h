#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "RenegadeVehicleAITypes.h"
#include "RenegadeVehicleAIBlueprintLibrary.generated.h"

class AActor;
class ARenegadeHarvestPoint;
class ARenegadeVehicleSplinePath;
class URenegadeHarvesterComponent;
class URenegadeVehicleDriverComponent;

UCLASS()
class RENEGADEVEHICLEAI_API URenegadeVehicleAIBlueprintLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Lookup", meta = (WorldContext = "WorldContextObject"))
    static ARenegadeVehicleSplinePath* FindNearestCompatibleVehiclePath(
        const UObject* WorldContextObject,
        FVector WorldLocation,
        int32 TeamId,
        FName RequiredRouteGroup = NAME_None,
        ERenegadeVehicleRoutePurpose RequiredPurpose = ERenegadeVehicleRoutePurpose::General,
        bool bRequirePurposeMatch = false);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Lookup", meta = (WorldContext = "WorldContextObject"))
    static ARenegadeHarvestPoint* FindNearestAvailableHarvestPoint(
        const UObject* WorldContextObject,
        FVector WorldLocation,
        int32 TeamId,
        FName RequiredHarvestGroup = NAME_None);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Lookup")
    static URenegadeVehicleDriverComponent* GetVehicleDriverComponent(AActor* VehicleActor);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Lookup")
    static URenegadeHarvesterComponent* GetHarvesterComponent(AActor* VehicleActor);
};
