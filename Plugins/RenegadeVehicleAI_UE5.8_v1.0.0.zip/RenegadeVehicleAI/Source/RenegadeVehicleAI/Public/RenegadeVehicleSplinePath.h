#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RenegadeVehicleAITypes.h"
#include "RenegadeVehicleSplinePath.generated.h"

class USceneComponent;
class USplineComponent;

UCLASS(BlueprintType, Blueprintable)
class RENEGADEVEHICLEAI_API ARenegadeVehicleSplinePath : public AActor
{
    GENERATED_BODY()

public:
    ARenegadeVehicleSplinePath();

    virtual void OnConstruction(const FTransform& Transform) override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Route")
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Route")
    TObjectPtr<USplineComponent> RouteSpline;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    FName RouteGroup = NAME_None;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    ERenegadeVehicleRoutePurpose RoutePurpose = ERenegadeVehicleRoutePurpose::General;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    TArray<int32> AllowedTeamIds;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    bool bClosedLoop = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route")
    bool bAllowReverseTravel = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "0.0", Units = "km/h"))
    float SpeedLimitKPH = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Route", meta = (ClampMin = "0.0", Units = "cm"))
    float RecommendedLaneSpacing = 260.0f;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    bool IsTeamAllowed(int32 TeamId) const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    float GetRouteLength() const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    float GetDistanceClosestToWorldLocation(const FVector& WorldLocation) const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    FVector GetWorldLocationAtDistance(float DistanceAlongSpline, float LaneOffset = 0.0f) const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    FVector GetWorldDirectionAtDistance(float DistanceAlongSpline) const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Route")
    FVector GetWorldRightVectorAtDistance(float DistanceAlongSpline) const;
};
