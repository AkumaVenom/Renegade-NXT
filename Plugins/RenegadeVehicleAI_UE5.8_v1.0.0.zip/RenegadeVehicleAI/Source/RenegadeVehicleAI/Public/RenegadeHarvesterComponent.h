#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "RenegadeVehicleAITypes.h"
#include "RenegadeHarvesterComponent.generated.h"

class ARenegadeHarvestPoint;
class ARenegadeRefineryDock;
class ARenegadeVehicleSplinePath;
class URenegadeVehicleDriverComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRenegadeHarvesterStateChangedSignature, ERenegadeHarvesterState, PreviousState, ERenegadeHarvesterState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRenegadeHarvesterCargoChangedSignature, float, CurrentCargo, float, CargoCapacity);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeHarvesterDeliverySignature, float, DeliveredAmount);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRenegadeHarvesterCycleSignature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRenegadeHarvesterFaultSignature, FString, Message);

UCLASS(ClassGroup = (Renegade), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class RENEGADEVEHICLEAI_API URenegadeHarvesterComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    URenegadeHarvesterComponent();

    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    bool bAutoStart = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    bool bRepeatCycle = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    TObjectPtr<ARenegadeVehicleSplinePath> OutboundPath = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    TObjectPtr<ARenegadeVehicleSplinePath> ReturnPath = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    bool bReverseOutboundPathWhenReturnPathMissing = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    TObjectPtr<ARenegadeHarvestPoint> HarvestPoint = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    TObjectPtr<ARenegadeRefineryDock> RefineryDock = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "1.0"))
    float CargoCapacity = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "0.01"))
    float HarvestRatePerSecond = 12.5f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "0.01"))
    float UnloadRatePerSecond = 25.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "1.0", Units = "km/h"))
    float DockApproachSpeedKPH = 8.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "0.0", Units = "s"))
    float RestartDelayAtRefinery = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester", meta = (ClampMin = "0.1", Units = "s"))
    float ReservationRetryInterval = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Harvester")
    bool bPauseWorkDuringCombatMovement = true;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Harvester")
    ERenegadeHarvesterState HarvesterState = ERenegadeHarvesterState::Idle;

    UPROPERTY(Replicated, VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Harvester")
    float CurrentCargo = 0.0f;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterStateChangedSignature OnHarvesterStateChanged;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterCargoChangedSignature OnCargoChanged;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterDeliverySignature OnCargoDelivered;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterCycleSignature OnHarvestCycleStarted;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterCycleSignature OnHarvestCycleCompleted;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Harvester|Events")
    FRenegadeHarvesterFaultSignature OnHarvesterFault;

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvester")
    bool StartHarvestCycle();

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvester")
    void StopHarvestCycle(bool bApplyBrake = true);

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Harvester")
    void SetCurrentCargo(float NewCargo);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Harvester")
    bool IsCargoFull() const;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Harvester")
    URenegadeVehicleDriverComponent* GetDriverComponent() const { return DriverComponent; }

private:
    UPROPERTY(Transient)
    TObjectPtr<URenegadeVehicleDriverComponent> DriverComponent = nullptr;

    float ReservationRetryCountdown = 0.0f;
    float RestartCountdown = 0.0f;
    float PendingDeliveryAmount = 0.0f;

    void SetHarvesterState(ERenegadeHarvesterState NewState);
    bool ResolveDriverComponent();
    bool ValidateConfiguration(bool bBroadcastFault);
    void BeginHarvesting();
    void BeginReturnToRefinery();
    void BeginUnloading();
    void RestartAfterRefinery();
    void UpdateHarvesting(float DeltaTime);
    void UpdateWaitingForHarvestPoint(float DeltaTime);
    void UpdateUnloading(float DeltaTime);
    void UpdateWaitingAtRefinery(float DeltaTime);
    bool IsWorkPausedForCombat() const;

    UFUNCTION()
    void HandleRouteCompleted(ARenegadeVehicleSplinePath* CompletedPath);

    UFUNCTION()
    void HandleWorldTargetReached();
};
