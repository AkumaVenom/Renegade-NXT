#pragma once

#include "CoreMinimal.h"
#include "RenegadeVehicleAITypes.generated.h"

UENUM(BlueprintType)
enum class ERenegadeVehicleDriveState : uint8
{
    Idle                UMETA(DisplayName = "Idle"),
    FollowingRoute      UMETA(DisplayName = "Following Route"),
    CombatManeuver      UMETA(DisplayName = "Combat Manoeuvre"),
    CombatPaused        UMETA(DisplayName = "Combat Paused"),
    MovingToWorldTarget UMETA(DisplayName = "Moving To World Target"),
    WaitingToResume     UMETA(DisplayName = "Waiting To Resume"),
    StuckRecovery       UMETA(DisplayName = "Stuck Recovery"),
    RouteComplete       UMETA(DisplayName = "Route Complete"),
    Disabled            UMETA(DisplayName = "Disabled")
};

UENUM(BlueprintType)
enum class ERenegadeVehicleRouteDirection : uint8
{
    Forward UMETA(DisplayName = "Spline Forward"),
    Reverse UMETA(DisplayName = "Spline Reverse")
};

UENUM(BlueprintType)
enum class ERenegadeVehicleRoutePurpose : uint8
{
    General            UMETA(DisplayName = "General"),
    Combat             UMETA(DisplayName = "Combat"),
    Patrol             UMETA(DisplayName = "Patrol"),
    HarvesterOutbound  UMETA(DisplayName = "Harvester Outbound"),
    HarvesterReturn    UMETA(DisplayName = "Harvester Return"),
    RefineryApproach   UMETA(DisplayName = "Refinery Approach")
};

UENUM(BlueprintType)
enum class ERenegadeVehicleCombatManeuver : uint8
{
    DynamicStandoff UMETA(DisplayName = "Dynamic Standoff"),
    OrbitTarget     UMETA(DisplayName = "Orbit Target"),
    AdvanceAndHold  UMETA(DisplayName = "Advance And Hold"),
    HoldPosition    UMETA(DisplayName = "Hold Position")
};

UENUM(BlueprintType)
enum class ERenegadeHarvesterState : uint8
{
    Idle                   UMETA(DisplayName = "Idle"),
    DrivingToHarvest       UMETA(DisplayName = "Driving To Harvest"),
    ApproachingHarvest     UMETA(DisplayName = "Approaching Harvest"),
    WaitingForHarvestPoint UMETA(DisplayName = "Waiting For Harvest Point"),
    Harvesting             UMETA(DisplayName = "Harvesting"),
    DrivingToRefinery      UMETA(DisplayName = "Driving To Refinery"),
    ApproachingRefinery    UMETA(DisplayName = "Approaching Refinery"),
    Unloading              UMETA(DisplayName = "Unloading"),
    WaitingAtRefinery      UMETA(DisplayName = "Waiting At Refinery"),
    Disabled               UMETA(DisplayName = "Disabled")
};
