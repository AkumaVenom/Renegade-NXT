#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RenegadeRefineryDock.generated.h"

class USceneComponent;
class USphereComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRenegadeRefineryDeliverySignature, AActor*, Harvester, float, DeliveredAmount);

UCLASS(BlueprintType, Blueprintable)
class RENEGADEVEHICLEAI_API ARenegadeRefineryDock : public AActor
{
    GENERATED_BODY()

public:
    ARenegadeRefineryDock();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Refinery")
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Renegade Vehicle AI|Refinery")
    TObjectPtr<USphereComponent> DockingVolume;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Refinery")
    int32 TeamId = INDEX_NONE;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Renegade Vehicle AI|Refinery", meta = (ClampMin = "0.01"))
    float UnloadRateMultiplier = 1.0f;

    UPROPERTY(BlueprintAssignable, Category = "Renegade Vehicle AI|Refinery")
    FRenegadeRefineryDeliverySignature OnDeliveryReceived;

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Refinery")
    bool AcceptsTeam(int32 HarvesterTeamId) const;

    UFUNCTION(BlueprintCallable, Category = "Renegade Vehicle AI|Refinery")
    void ReceiveDelivery(AActor* Harvester, float DeliveredAmount);

    UFUNCTION(BlueprintPure, Category = "Renegade Vehicle AI|Refinery")
    float GetDockingRadius() const;
};
