using UnrealBuildTool;

public class RenegadeVehicleAI : ModuleRules
{
    public RenegadeVehicleAI(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "ChaosVehicles"
            }
        );

        PrivateDependencyModuleNames.AddRange(
            new string[]
            {
                "PhysicsCore"
            }
        );
    }
}
