#include "RenegadeVehicleSplinePath.h"

#include "Components/SceneComponent.h"
#include "Components/SplineComponent.h"

ARenegadeVehicleSplinePath::ARenegadeVehicleSplinePath()
{
    PrimaryActorTick.bCanEverTick = false;

    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SetRootComponent(SceneRoot);

    RouteSpline = CreateDefaultSubobject<USplineComponent>(TEXT("RouteSpline"));
    RouteSpline->SetupAttachment(SceneRoot);
    RouteSpline->SetClosedLoop(false);
}

void ARenegadeVehicleSplinePath::OnConstruction(const FTransform& Transform)
{
    Super::OnConstruction(Transform);

    if (RouteSpline)
    {
        RouteSpline->SetClosedLoop(bClosedLoop, true);
    }
}

bool ARenegadeVehicleSplinePath::IsTeamAllowed(const int32 InTeamId) const
{
    return AllowedTeamIds.IsEmpty() || AllowedTeamIds.Contains(InTeamId);
}

float ARenegadeVehicleSplinePath::GetRouteLength() const
{
    return RouteSpline ? RouteSpline->GetSplineLength() : 0.0f;
}

float ARenegadeVehicleSplinePath::GetDistanceClosestToWorldLocation(const FVector& WorldLocation) const
{
    return RouteSpline
        ? RouteSpline->GetDistanceAlongSplineAtLocation(WorldLocation, ESplineCoordinateSpace::World)
        : 0.0f;
}

FVector ARenegadeVehicleSplinePath::GetWorldLocationAtDistance(const float DistanceAlongSpline, const float InLaneOffset) const
{
    if (!RouteSpline)
    {
        return GetActorLocation();
    }

    const float RouteLength = RouteSpline->GetSplineLength();
    const float SafeDistance = bClosedLoop && RouteLength > KINDA_SMALL_NUMBER
        ? FMath::Fmod(FMath::Fmod(DistanceAlongSpline, RouteLength) + RouteLength, RouteLength)
        : FMath::Clamp(DistanceAlongSpline, 0.0f, RouteLength);

    const FVector Center = RouteSpline->GetLocationAtDistanceAlongSpline(SafeDistance, ESplineCoordinateSpace::World);
    const FVector Right = GetWorldRightVectorAtDistance(SafeDistance);
    return Center + Right * InLaneOffset;
}

FVector ARenegadeVehicleSplinePath::GetWorldDirectionAtDistance(const float DistanceAlongSpline) const
{
    if (!RouteSpline)
    {
        return GetActorForwardVector();
    }

    const float RouteLength = RouteSpline->GetSplineLength();
    const float SafeDistance = bClosedLoop && RouteLength > KINDA_SMALL_NUMBER
        ? FMath::Fmod(FMath::Fmod(DistanceAlongSpline, RouteLength) + RouteLength, RouteLength)
        : FMath::Clamp(DistanceAlongSpline, 0.0f, RouteLength);

    return RouteSpline->GetDirectionAtDistanceAlongSpline(SafeDistance, ESplineCoordinateSpace::World);
}

FVector ARenegadeVehicleSplinePath::GetWorldRightVectorAtDistance(const float DistanceAlongSpline) const
{
    if (!RouteSpline)
    {
        return GetActorRightVector();
    }

    const float RouteLength = RouteSpline->GetSplineLength();
    const float SafeDistance = bClosedLoop && RouteLength > KINDA_SMALL_NUMBER
        ? FMath::Fmod(FMath::Fmod(DistanceAlongSpline, RouteLength) + RouteLength, RouteLength)
        : FMath::Clamp(DistanceAlongSpline, 0.0f, RouteLength);

    return RouteSpline->GetRightVectorAtDistanceAlongSpline(SafeDistance, ESplineCoordinateSpace::World);
}
