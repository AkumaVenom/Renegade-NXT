#include "RenegadeVehicleAIBlueprintLibrary.h"

#include "Engine/Engine.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "RenegadeHarvestPoint.h"
#include "RenegadeHarvesterComponent.h"
#include "RenegadeVehicleDriverComponent.h"
#include "RenegadeVehicleSplinePath.h"

ARenegadeVehicleSplinePath* URenegadeVehicleAIBlueprintLibrary::FindNearestCompatibleVehiclePath(
    const UObject* WorldContextObject,
    const FVector WorldLocation,
    const int32 TeamId,
    const FName RequiredRouteGroup,
    const ERenegadeVehicleRoutePurpose RequiredPurpose,
    const bool bRequirePurposeMatch)
{
    UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
    if (!World)
    {
        return nullptr;
    }

    ARenegadeVehicleSplinePath* BestPath = nullptr;
    float BestDistanceSquared = TNumericLimits<float>::Max();

    for (TActorIterator<ARenegadeVehicleSplinePath> It(World); It; ++It)
    {
        ARenegadeVehicleSplinePath* Candidate = *It;
        if (!IsValid(Candidate) || !Candidate->IsTeamAllowed(TeamId))
        {
            continue;
        }

        if (!RequiredRouteGroup.IsNone() && Candidate->RouteGroup != RequiredRouteGroup)
        {
            continue;
        }

        if (bRequirePurposeMatch && Candidate->RoutePurpose != RequiredPurpose)
        {
            continue;
        }

        const FVector ClosestLocation = Candidate->GetWorldLocationAtDistance(Candidate->GetDistanceClosestToWorldLocation(WorldLocation));
        const float DistanceSquared = FVector::DistSquared2D(WorldLocation, ClosestLocation);
        if (DistanceSquared < BestDistanceSquared)
        {
            BestDistanceSquared = DistanceSquared;
            BestPath = Candidate;
        }
    }

    return BestPath;
}

ARenegadeHarvestPoint* URenegadeVehicleAIBlueprintLibrary::FindNearestAvailableHarvestPoint(
    const UObject* WorldContextObject,
    const FVector WorldLocation,
    const int32 TeamId,
    const FName RequiredHarvestGroup)
{
    UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
    if (!World)
    {
        return nullptr;
    }

    ARenegadeHarvestPoint* BestPoint = nullptr;
    float BestDistanceSquared = TNumericLimits<float>::Max();

    for (TActorIterator<ARenegadeHarvestPoint> It(World); It; ++It)
    {
        ARenegadeHarvestPoint* Candidate = *It;
        if (!IsValid(Candidate) || !Candidate->IsTeamAllowed(TeamId) || !Candidate->IsAvailableFor(nullptr))
        {
            continue;
        }

        if (!RequiredHarvestGroup.IsNone() && Candidate->HarvestGroup != RequiredHarvestGroup)
        {
            continue;
        }

        const float DistanceSquared = FVector::DistSquared2D(WorldLocation, Candidate->GetActorLocation());
        if (DistanceSquared < BestDistanceSquared)
        {
            BestDistanceSquared = DistanceSquared;
            BestPoint = Candidate;
        }
    }

    return BestPoint;
}

URenegadeVehicleDriverComponent* URenegadeVehicleAIBlueprintLibrary::GetVehicleDriverComponent(AActor* VehicleActor)
{
    return IsValid(VehicleActor) ? VehicleActor->FindComponentByClass<URenegadeVehicleDriverComponent>() : nullptr;
}

URenegadeHarvesterComponent* URenegadeVehicleAIBlueprintLibrary::GetHarvesterComponent(AActor* VehicleActor)
{
    return IsValid(VehicleActor) ? VehicleActor->FindComponentByClass<URenegadeHarvesterComponent>() : nullptr;
}
