#include "RenegadeVehicleDriverComponent.h"

#include "ChaosVehicleMovementComponent.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Net/UnrealNetwork.h"
#include "RenegadeVehicleSplinePath.h"

namespace RenegadeVehicleAI
{
    constexpr float CmPerSecondToKPH = 0.036f;
}

URenegadeVehicleDriverComponent::URenegadeVehicleDriverComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    PrimaryComponentTick.TickGroup = TG_PrePhysics;
    SetIsReplicatedByDefault(true);
}

void URenegadeVehicleDriverComponent::BeginPlay()
{
    Super::BeginPlay();

    ResolveVehicleMovement();

    if (HasAuthorityToDrive() && VehicleMovement)
    {
        VehicleMovement->SetRequiresControllerForInputs(!bAllowInputsWithoutController);
        VehicleMovement->SetUseAutomaticGears(true);
    }

    if (HasAuthorityToDrive() && bAutoStart && IsValid(AutoStartPath))
    {
        StartFollowing(AutoStartPath, true, AutoStartDirection, bAutoStartUseReverseGear);
    }
}

void URenegadeVehicleDriverComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (HasAuthorityToDrive())
    {
        ApplyStopInputs(true);
    }

    Super::EndPlay(EndPlayReason);
}

void URenegadeVehicleDriverComponent::TickComponent(
    const float DeltaTime,
    const ELevelTick TickType,
    FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (!HasAuthorityToDrive())
    {
        return;
    }

    if (!VehicleMovement && !ResolveVehicleMovement())
    {
        SetDriveState(ERenegadeVehicleDriveState::Disabled);
        return;
    }

    switch (DriveState)
    {
        case ERenegadeVehicleDriveState::FollowingRoute:
            UpdateRouteDriving(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::CombatManeuver:
            UpdateCombatDriving(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::CombatPaused:
            UpdateCombatPaused(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::RouteComplete:
        case ERenegadeVehicleDriveState::Idle:
            ApplyStopInputs(true);
            break;

        case ERenegadeVehicleDriveState::MovingToWorldTarget:
            UpdateWorldTargetDriving(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::WaitingToResume:
            UpdateWaitingToResume(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::StuckRecovery:
            UpdateStuckRecovery(DeltaTime);
            break;

        case ERenegadeVehicleDriveState::Disabled:
        default:
            ApplyStopInputs(true);
            return;
    }

    if (DriveState != ERenegadeVehicleDriveState::StuckRecovery)
    {
        UpdateStuckDetection(DeltaTime);
    }
}

void URenegadeVehicleDriverComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(URenegadeVehicleDriverComponent, DriveState);
    DOREPLIFETIME(URenegadeVehicleDriverComponent, AssignedPath);
    DOREPLIFETIME(URenegadeVehicleDriverComponent, CurrentDistanceAlongSpline);
    DOREPLIFETIME(URenegadeVehicleDriverComponent, TravelDirection);
    DOREPLIFETIME(URenegadeVehicleDriverComponent, bDriveAssignedRouteInReverseGear);
    DOREPLIFETIME(URenegadeVehicleDriverComponent, CombatTarget);
}

bool URenegadeVehicleDriverComponent::StartFollowing(
    ARenegadeVehicleSplinePath* Path,
    const bool bReacquireFromCurrentLocation,
    const ERenegadeVehicleRouteDirection Direction,
    const bool bUseReverseGear)
{
    if (!HasAuthorityToDrive() || !IsValid(Path) || !Path->RouteSpline)
    {
        return false;
    }

    if (!Path->IsTeamAllowed(TeamId))
    {
        const FString Message = FString::Printf(
            TEXT("Vehicle '%s' team %d is not permitted on route '%s'."),
            *GetNameSafe(GetOwner()),
            TeamId,
            *GetNameSafe(Path));
        OnDriverFault.Broadcast(Message);
        return false;
    }

    if (Direction == ERenegadeVehicleRouteDirection::Reverse && !Path->bAllowReverseTravel)
    {
        const FString Message = FString::Printf(TEXT("Route '%s' does not allow reverse travel."), *GetNameSafe(Path));
        OnDriverFault.Broadcast(Message);
        return false;
    }

    if (!VehicleMovement && !ResolveVehicleMovement())
    {
        OnDriverFault.Broadcast(TEXT("No UChaosVehicleMovementComponent was found on the vehicle actor."));
        SetDriveState(ERenegadeVehicleDriveState::Disabled);
        return false;
    }

    const float RouteLength = Path->GetRouteLength();
    if (RouteLength <= KINDA_SMALL_NUMBER)
    {
        OnDriverFault.Broadcast(FString::Printf(TEXT("Route '%s' has no usable spline length."), *GetNameSafe(Path)));
        return false;
    }

    AssignedPath = Path;
    TravelDirection = Direction;
    bDriveAssignedRouteInReverseGear = bUseReverseGear;

    if (bReacquireFromCurrentLocation && GetOwner())
    {
        CurrentDistanceAlongSpline = Path->GetDistanceClosestToWorldLocation(GetOwner()->GetActorLocation());
    }
    else
    {
        CurrentDistanceAlongSpline = Direction == ERenegadeVehicleRouteDirection::Forward ? 0.0f : RouteLength;
    }

    CurrentDistanceAlongSpline = FMath::Clamp(CurrentDistanceAlongSpline, 0.0f, RouteLength);
    ResumeCountdown = 0.0f;
    StuckAccumulator = 0.0f;
    SetDriveState(ERenegadeVehicleDriveState::FollowingRoute);
    return true;
}

void URenegadeVehicleDriverComponent::StopDriving(const bool bClearAssignedPath, const bool bApplyBrake)
{
    if (!HasAuthorityToDrive())
    {
        return;
    }

    ApplyStopInputs(bApplyBrake);
    if (CombatTarget != nullptr)
    {
        CombatTarget = nullptr;
        OnCombatTargetChanged.Broadcast(nullptr);
    }
    bHadRouteBeforeCombat = false;
    PendingResumeState = ERenegadeVehicleDriveState::Idle;
    ResumeCountdown = 0.0f;
    StuckAccumulator = 0.0f;

    if (bClearAssignedPath)
    {
        AssignedPath = nullptr;
        CurrentDistanceAlongSpline = 0.0f;
    }

    SetDriveState(ERenegadeVehicleDriveState::Idle);
}

bool URenegadeVehicleDriverComponent::ResumeFollowing()
{
    if (!HasAuthorityToDrive() || !IsValid(AssignedPath) || !GetOwner())
    {
        return false;
    }

    const float ClosestDistance = AssignedPath->GetDistanceClosestToWorldLocation(GetOwner()->GetActorLocation());
    if (bPreserveProgressWhenResuming && !AssignedPath->bClosedLoop)
    {
        if (TravelDirection == ERenegadeVehicleRouteDirection::Forward)
        {
            CurrentDistanceAlongSpline = FMath::Max(ClosestDistance, CurrentDistanceAlongSpline - MaximumResumeBacktrack);
        }
        else
        {
            CurrentDistanceAlongSpline = FMath::Min(ClosestDistance, CurrentDistanceAlongSpline + MaximumResumeBacktrack);
        }
    }
    else
    {
        CurrentDistanceAlongSpline = ClosestDistance;
    }

    ResumeCountdown = 0.0f;
    SetDriveState(ERenegadeVehicleDriveState::FollowingRoute);
    return true;
}

void URenegadeVehicleDriverComponent::SetCombatActive(
    const bool bCombatActive,
    AActor* NewCombatTarget,
    const float ResumeDelayOverride)
{
    if (!HasAuthorityToDrive())
    {
        return;
    }

    const bool bCurrentlyInCombat = DriveState == ERenegadeVehicleDriveState::CombatManeuver ||
        DriveState == ERenegadeVehicleDriveState::CombatPaused;

    if (bCombatActive)
    {
        const bool bTargetChanged = CombatTarget != NewCombatTarget;

        if (!bCurrentlyInCombat)
        {
            StateBeforeCombat = DriveState == ERenegadeVehicleDriveState::StuckRecovery
                ? StateBeforeRecovery
                : DriveState;
        }

        bHadRouteBeforeCombat = StateBeforeCombat == ERenegadeVehicleDriveState::FollowingRoute ||
            StateBeforeCombat == ERenegadeVehicleDriveState::WaitingToResume ||
            (bHadRouteBeforeCombat && IsValid(AssignedPath));

        if (bTargetChanged)
        {
            CombatTarget = NewCombatTarget;
            OnCombatTargetChanged.Broadcast(CombatTarget);
        }

        ResumeCountdown = 0.0f;

        if (!bCurrentlyInCombat || bTargetChanged)
        {
            CombatReplanCountdown = 0.0f;
            FireRequestCountdown = 0.0f;
            CombatOrbitSign = FMath::RandBool() ? 1 : -1;
        }

        if (bEnableCombatManeuvering && IsValid(CombatTarget))
        {
            if (!bCurrentlyInCombat || bTargetChanged || DriveState != ERenegadeVehicleDriveState::CombatManeuver)
            {
                ReplanCombatDestination();
            }
            SetDriveState(ERenegadeVehicleDriveState::CombatManeuver);
        }
        else
        {
            SetDriveState(ERenegadeVehicleDriveState::CombatPaused);
        }

        return;
    }

    // Ending combat is deliberately idempotent. A Behavior Tree or combat component may
    // call this repeatedly while no enemy exists; those calls must not cancel route driving.
    if (!bCurrentlyInCombat)
    {
        if (CombatTarget != nullptr)
        {
            CombatTarget = nullptr;
            OnCombatTargetChanged.Broadcast(nullptr);
        }
        return;
    }

    if (CombatTarget != nullptr)
    {
        CombatTarget = nullptr;
        OnCombatTargetChanged.Broadcast(nullptr);
    }

    PendingResumeState = ERenegadeVehicleDriveState::Idle;
    if (bResumeRouteAfterCombat && bHadRouteBeforeCombat && IsValid(AssignedPath))
    {
        PendingResumeState = ERenegadeVehicleDriveState::FollowingRoute;
    }
    else if (StateBeforeCombat == ERenegadeVehicleDriveState::MovingToWorldTarget)
    {
        PendingResumeState = ERenegadeVehicleDriveState::MovingToWorldTarget;
    }

    if (PendingResumeState != ERenegadeVehicleDriveState::Idle)
    {
        ResumeCountdown = ResumeDelayOverride >= 0.0f ? ResumeDelayOverride : DefaultCombatResumeDelay;
        SetDriveState(ERenegadeVehicleDriveState::WaitingToResume);
    }
    else
    {
        bHadRouteBeforeCombat = false;
        SetDriveState(ERenegadeVehicleDriveState::Idle);
    }
}

bool URenegadeVehicleDriverComponent::SetWorldMoveTarget(
    const FVector InWorldTarget,
    const float DesiredSpeedKPH,
    const float AcceptanceRadius)
{
    if (!HasAuthorityToDrive())
    {
        return false;
    }

    if (!VehicleMovement && !ResolveVehicleMovement())
    {
        OnDriverFault.Broadcast(TEXT("Cannot set a world move target because no Chaos vehicle movement component was found."));
        return false;
    }

    WorldMoveTarget = InWorldTarget;
    WorldMoveDesiredSpeedKPH = FMath::Max(1.0f, DesiredSpeedKPH);
    WorldMoveAcceptanceRadius = FMath::Max(25.0f, AcceptanceRadius);
    SetDriveState(ERenegadeVehicleDriveState::MovingToWorldTarget);
    return true;
}

void URenegadeVehicleDriverComponent::ClearWorldMoveTarget(const bool bApplyBrake)
{
    if (!HasAuthorityToDrive())
    {
        return;
    }

    ApplyStopInputs(bApplyBrake);
    if (PendingResumeState == ERenegadeVehicleDriveState::MovingToWorldTarget)
    {
        PendingResumeState = ERenegadeVehicleDriveState::Idle;
    }
    if (StateBeforeCombat == ERenegadeVehicleDriveState::MovingToWorldTarget)
    {
        StateBeforeCombat = ERenegadeVehicleDriveState::Idle;
    }
    SetDriveState(ERenegadeVehicleDriveState::Idle);
}

void URenegadeVehicleDriverComponent::SetDrivingEnabled(const bool bEnabled)
{
    if (!HasAuthorityToDrive())
    {
        return;
    }

    if (bEnabled)
    {
        if (DriveState == ERenegadeVehicleDriveState::Disabled)
        {
            if (ResolveVehicleMovement())
            {
                SetDriveState(ERenegadeVehicleDriveState::Idle);
            }
            else
            {
                OnDriverFault.Broadcast(TEXT("Driving could not be enabled because no Chaos vehicle movement component was found."));
            }
        }
    }
    else
    {
        ApplyStopInputs(true);
        if (CombatTarget != nullptr)
        {
            CombatTarget = nullptr;
            OnCombatTargetChanged.Broadcast(nullptr);
        }
        PendingResumeState = ERenegadeVehicleDriveState::Idle;
        SetDriveState(ERenegadeVehicleDriveState::Disabled);
    }
}

float URenegadeVehicleDriverComponent::GetForwardSpeedKPH() const
{
    return VehicleMovement
        ? FMath::Abs(VehicleMovement->GetForwardSpeed()) * RenegadeVehicleAI::CmPerSecondToKPH
        : 0.0f;
}

bool URenegadeVehicleDriverComponent::IsInCombatMovement() const
{
    return DriveState == ERenegadeVehicleDriveState::CombatManeuver ||
        DriveState == ERenegadeVehicleDriveState::CombatPaused;
}

bool URenegadeVehicleDriverComponent::ResolveVehicleMovement()
{
    VehicleMovement = GetOwner() ? GetOwner()->FindComponentByClass<UChaosVehicleMovementComponent>() : nullptr;

    if (VehicleMovement && HasAuthorityToDrive())
    {
        VehicleMovement->SetRequiresControllerForInputs(!bAllowInputsWithoutController);
    }

    return VehicleMovement != nullptr;
}

bool URenegadeVehicleDriverComponent::HasAuthorityToDrive() const
{
    const AActor* OwnerActor = GetOwner();
    return OwnerActor && OwnerActor->HasAuthority();
}

void URenegadeVehicleDriverComponent::SetDriveState(const ERenegadeVehicleDriveState NewState)
{
    if (DriveState == NewState)
    {
        return;
    }

    const ERenegadeVehicleDriveState PreviousState = DriveState;
    DriveState = NewState;
    OnDriveStateChanged.Broadcast(PreviousState, NewState);
}

void URenegadeVehicleDriverComponent::ApplyStopInputs(const bool bApplyBrake)
{
    if (!VehicleMovement)
    {
        return;
    }

    VehicleMovement->SetThrottleInput(0.0f);
    VehicleMovement->SetSteeringInput(0.0f);
    VehicleMovement->SetBrakeInput(bApplyBrake ? MaximumBrakeInput : 0.0f);
    VehicleMovement->SetHandbrakeInput(false);

    LastThrottleCommand = 0.0f;
    LastSteeringCommand = 0.0f;
    LastBrakeCommand = bApplyBrake ? MaximumBrakeInput : 0.0f;
}

void URenegadeVehicleDriverComponent::UpdateRouteDriving(const float DeltaTime)
{
    if (!IsValid(AssignedPath) || !GetOwner())
    {
        StopDriving(true, true);
        OnDriverFault.Broadcast(TEXT("The assigned vehicle route became invalid."));
        return;
    }

    const float ClosestDistance = AssignedPath->GetDistanceClosestToWorldLocation(GetOwner()->GetActorLocation());
    CurrentDistanceAlongSpline = GetStableRouteDistance(ClosestDistance);

    const float RemainingDistance = GetRemainingRouteDistance();
    if (!AssignedPath->bClosedLoop && RemainingDistance <= RouteEndTolerance)
    {
        CompleteRoute();
        return;
    }

    const FVector TargetPoint = GetRouteLookAheadTarget(RemainingDistance);

    float DesiredSpeed = CruiseSpeedKPH;
    if (AssignedPath->SpeedLimitKPH > 0.0f)
    {
        DesiredSpeed = FMath::Min(DesiredSpeed, AssignedPath->SpeedLimitKPH);
    }

    const bool bReverseGear = bDriveAssignedRouteInReverseGear;
    DriveTowardPoint(TargetPoint, DesiredSpeed, DeltaTime, bReverseGear, RemainingDistance);
}

void URenegadeVehicleDriverComponent::UpdateCombatDriving(const float DeltaTime)
{
    if (!IsValid(CombatTarget) || CombatTarget->IsActorBeingDestroyed())
    {
        SetCombatActive(false, nullptr, -1.0f);
        return;
    }

    CombatReplanCountdown -= DeltaTime;
    if (CombatReplanCountdown <= 0.0f)
    {
        ReplanCombatDestination();
    }

    FireRequestCountdown -= DeltaTime;
    if (FireRequestCountdown <= 0.0f)
    {
        FireRequestCountdown = FMath::Max(0.05f, FireRequestInterval);
        OnFireRequested.Broadcast(CombatTarget, CombatTarget->GetActorLocation());
    }

    if (CombatManeuver == ERenegadeVehicleCombatManeuver::HoldPosition)
    {
        ApplyStopInputs(true);
        return;
    }

    DriveTowardPoint(CombatDestination, CombatSpeedKPH, DeltaTime, false, FVector::Dist2D(GetOwner()->GetActorLocation(), CombatDestination));
}

void URenegadeVehicleDriverComponent::UpdateCombatPaused(const float DeltaTime)
{
    ApplyStopInputs(true);

    if (!IsValid(CombatTarget) || CombatTarget->IsActorBeingDestroyed())
    {
        SetCombatActive(false, nullptr, -1.0f);
        return;
    }

    FireRequestCountdown -= DeltaTime;
    if (FireRequestCountdown <= 0.0f)
    {
        FireRequestCountdown = FMath::Max(0.05f, FireRequestInterval);
        OnFireRequested.Broadcast(CombatTarget, CombatTarget->GetActorLocation());
    }
}

void URenegadeVehicleDriverComponent::UpdateWorldTargetDriving(const float DeltaTime)
{
    if (!GetOwner())
    {
        ClearWorldMoveTarget(true);
        return;
    }

    const float Distance = FVector::Dist2D(GetOwner()->GetActorLocation(), WorldMoveTarget);
    if (Distance <= WorldMoveAcceptanceRadius)
    {
        ApplyStopInputs(true);
        SetDriveState(ERenegadeVehicleDriveState::Idle);
        OnWorldTargetReached.Broadcast();
        return;
    }

    DriveTowardPoint(WorldMoveTarget, WorldMoveDesiredSpeedKPH, DeltaTime, false, Distance);
}

void URenegadeVehicleDriverComponent::UpdateWaitingToResume(const float DeltaTime)
{
    ApplyStopInputs(true);
    ResumeCountdown -= DeltaTime;
    if (ResumeCountdown <= 0.0f)
    {
        bHadRouteBeforeCombat = false;

        if (PendingResumeState == ERenegadeVehicleDriveState::FollowingRoute)
        {
            if (!ResumeFollowing())
            {
                SetDriveState(ERenegadeVehicleDriveState::Idle);
            }
        }
        else if (PendingResumeState == ERenegadeVehicleDriveState::MovingToWorldTarget)
        {
            SetDriveState(ERenegadeVehicleDriveState::MovingToWorldTarget);
        }
        else
        {
            SetDriveState(ERenegadeVehicleDriveState::Idle);
        }

        PendingResumeState = ERenegadeVehicleDriveState::Idle;
    }
}

void URenegadeVehicleDriverComponent::UpdateStuckRecovery(const float DeltaTime)
{
    if (!VehicleMovement)
    {
        SetDriveState(ERenegadeVehicleDriveState::Disabled);
        return;
    }

    RecoveryPhaseTime += DeltaTime;
    const float SteeringSign = RecoverySteeringSign;

    VehicleMovement->SetBrakeInput(0.0f);
    VehicleMovement->SetHandbrakeInput(false);
    VehicleMovement->SetSteeringInput(FMath::Clamp(SteeringSign, -1.0f, 1.0f));
    VehicleMovement->SetThrottleInput(0.65f);

    LastThrottleCommand = 0.65f;
    LastBrakeCommand = 0.0f;
    LastSteeringCommand = FMath::Clamp(SteeringSign, -1.0f, 1.0f);

    if (RecoveryPhase == 0)
    {
        VehicleMovement->SetUseAutomaticGears(false);
        VehicleMovement->SetTargetGear(-1, true);

        if (RecoveryPhaseTime >= RecoveryReverseTime)
        {
            RecoveryPhase = 1;
            RecoveryPhaseTime = 0.0f;
        }
        return;
    }

    VehicleMovement->SetUseAutomaticGears(true);
    VehicleMovement->SetTargetGear(1, true);

    if (RecoveryPhaseTime >= RecoveryForwardTime)
    {
        RecoveryPhase = 0;
        RecoveryPhaseTime = 0.0f;
        StuckAccumulator = 0.0f;

        ERenegadeVehicleDriveState ResumeState = StateBeforeRecovery;
        if (ResumeState == ERenegadeVehicleDriveState::CombatManeuver && !IsValid(CombatTarget))
        {
            ResumeState = IsValid(AssignedPath)
                ? ERenegadeVehicleDriveState::FollowingRoute
                : ERenegadeVehicleDriveState::Idle;
        }

        SetDriveState(ResumeState);
    }
}

void URenegadeVehicleDriverComponent::UpdateStuckDetection(const float DeltaTime)
{
    if (!bEnableStuckRecovery ||
        (DriveState != ERenegadeVehicleDriveState::FollowingRoute &&
         DriveState != ERenegadeVehicleDriveState::CombatManeuver &&
         DriveState != ERenegadeVehicleDriveState::MovingToWorldTarget))
    {
        StuckAccumulator = 0.0f;
        return;
    }

    if (LastThrottleCommand > 0.25f && LastBrakeCommand < 0.25f && GetForwardSpeedKPH() <= StuckSpeedThresholdKPH)
    {
        StuckAccumulator += DeltaTime;
    }
    else
    {
        StuckAccumulator = FMath::Max(0.0f, StuckAccumulator - DeltaTime * 2.0f);
    }

    if (StuckAccumulator >= StuckDetectionTime)
    {
        StateBeforeRecovery = DriveState;
        RecoverySteeringSign = FMath::Abs(LastSteeringCommand) > 0.1f
            ? -FMath::Sign(LastSteeringCommand)
            : static_cast<float>(CombatOrbitSign);
        RecoveryPhase = 0;
        RecoveryPhaseTime = 0.0f;
        StuckAccumulator = 0.0f;
        SetDriveState(ERenegadeVehicleDriveState::StuckRecovery);
    }
}

void URenegadeVehicleDriverComponent::CompleteRoute()
{
    ARenegadeVehicleSplinePath* CompletedPath = AssignedPath;
    ApplyStopInputs(true);
    SetDriveState(ERenegadeVehicleDriveState::RouteComplete);
    OnRouteCompleted.Broadcast(CompletedPath);
}

void URenegadeVehicleDriverComponent::ReplanCombatDestination()
{
    CombatReplanCountdown = FMath::Max(0.1f, CombatReplanInterval);

    if (!GetOwner() || !IsValid(CombatTarget))
    {
        CombatDestination = GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
        return;
    }

    const FVector OwnerLocation = GetOwner()->GetActorLocation();
    const FVector TargetLocation = CombatTarget->GetActorLocation();
    FVector Radial = OwnerLocation - TargetLocation;
    Radial.Z = 0.0f;

    const float DistanceToTarget = Radial.Size();
    Radial = Radial.GetSafeNormal();
    if (Radial.IsNearlyZero())
    {
        Radial = -GetOwner()->GetActorForwardVector().GetSafeNormal2D();
    }

    if (CombatManeuver == ERenegadeVehicleCombatManeuver::HoldPosition)
    {
        CombatDestination = OwnerLocation;
        return;
    }

    if (CombatManeuver == ERenegadeVehicleCombatManeuver::AdvanceAndHold)
    {
        CombatDestination = TargetLocation + Radial * PreferredCombatDistance;
        return;
    }

    if (CombatManeuver == ERenegadeVehicleCombatManeuver::DynamicStandoff)
    {
        if (DistanceToTarget < MinimumCombatDistance)
        {
            const FVector Tangent = FVector::CrossProduct(FVector::UpVector, Radial) * static_cast<float>(CombatOrbitSign);
            CombatDestination = OwnerLocation + Radial * 1400.0f + Tangent * 500.0f;
            return;
        }

        if (DistanceToTarget > MaximumCombatDistance)
        {
            CombatDestination = TargetLocation + Radial * PreferredCombatDistance;
            return;
        }
    }

    const FVector AdvancedRadial = Radial.RotateAngleAxis(CombatOrbitAdvanceDegrees * static_cast<float>(CombatOrbitSign), FVector::UpVector);
    CombatDestination = TargetLocation + AdvancedRadial * PreferredCombatDistance;
}

float URenegadeVehicleDriverComponent::GetStableRouteDistance(const float ClosestDistance) const
{
    if (!IsValid(AssignedPath) || AssignedPath->bClosedLoop)
    {
        return ClosestDistance;
    }

    const float PerTickBacktrackAllowance = FMath::Max(250.0f, MinimumLookAheadDistance);
    if (TravelDirection == ERenegadeVehicleRouteDirection::Forward)
    {
        return FMath::Max(ClosestDistance, CurrentDistanceAlongSpline - PerTickBacktrackAllowance);
    }

    return FMath::Min(ClosestDistance, CurrentDistanceAlongSpline + PerTickBacktrackAllowance);
}

float URenegadeVehicleDriverComponent::GetRemainingRouteDistance() const
{
    if (!IsValid(AssignedPath))
    {
        return 0.0f;
    }

    if (AssignedPath->bClosedLoop)
    {
        return AssignedPath->GetRouteLength();
    }

    return TravelDirection == ERenegadeVehicleRouteDirection::Forward
        ? FMath::Max(0.0f, AssignedPath->GetRouteLength() - CurrentDistanceAlongSpline)
        : FMath::Max(0.0f, CurrentDistanceAlongSpline);
}

FVector URenegadeVehicleDriverComponent::GetRouteLookAheadTarget(const float RemainingDistance) const
{
    if (!IsValid(AssignedPath))
    {
        return GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
    }

    const float AdaptiveLookAhead = FMath::Clamp(RemainingDistance * 0.5f, MinimumLookAheadDistance, LookAheadDistance);
    const float DirectionSign = TravelDirection == ERenegadeVehicleRouteDirection::Forward ? 1.0f : -1.0f;
    const float TargetDistance = CurrentDistanceAlongSpline + AdaptiveLookAhead * DirectionSign;
    return AssignedPath->GetWorldLocationAtDistance(TargetDistance, LaneOffset);
}

void URenegadeVehicleDriverComponent::DriveTowardPoint(
    const FVector& TargetPoint,
    const float DesiredSpeedKPH,
    const float /*DeltaTime*/,
    const bool bReverseGear,
    const float DistanceForBraking)
{
    if (!VehicleMovement || !GetOwner())
    {
        return;
    }

    FVector ToTarget = TargetPoint - GetOwner()->GetActorLocation();
    ToTarget.Z = 0.0f;
    const float DistanceToTarget = ToTarget.Size();
    if (DistanceToTarget <= KINDA_SMALL_NUMBER)
    {
        ApplyStopInputs(true);
        return;
    }

    const FVector DirectionToTarget = ToTarget / DistanceToTarget;
    const FVector Forward = GetOwner()->GetActorForwardVector().GetSafeNormal2D();
    const FVector Right = GetOwner()->GetActorRightVector().GetSafeNormal2D();
    const FVector EffectiveForward = bReverseGear ? -Forward : Forward;

    const float ForwardDot = FVector::DotProduct(EffectiveForward, DirectionToTarget);
    const float RightDot = FVector::DotProduct(Right, DirectionToTarget);
    const float HeadingRadians = FMath::Atan2(RightDot, ForwardDot);
    const float HeadingDegrees = FMath::RadiansToDegrees(HeadingRadians);

    float Steering = (HeadingDegrees / FMath::Max(5.0f, FullSteeringAngleDegrees)) * SteeringGain;
    if (bReverseGear)
    {
        Steering *= -1.0f;
    }

    float ObstacleSteeringBias = 0.0f;
    float ObstacleSpeedScale = 1.0f;
    CalculateObstacleAvoidance(bReverseGear, ObstacleSteeringBias, ObstacleSpeedScale);
    Steering += ObstacleSteeringBias;
    Steering = FMath::Clamp(Steering, -1.0f, 1.0f);

    float TargetSpeed = FMath::Max(1.0f, DesiredSpeedKPH);
    const float AbsoluteHeading = FMath::Abs(HeadingDegrees);
    if (AbsoluteHeading > SlowTurnAngleDegrees)
    {
        const float TurnAlpha = FMath::Clamp((AbsoluteHeading - SlowTurnAngleDegrees) / FMath::Max(1.0f, 90.0f - SlowTurnAngleDegrees), 0.0f, 1.0f);
        const float ReducedTurnSpeed = FMath::Min(TargetSpeed, TurnSpeedKPH);
        TargetSpeed = FMath::Lerp(TargetSpeed, ReducedTurnSpeed, TurnAlpha);
    }

    TargetSpeed *= ObstacleSpeedScale;

    if (DistanceForBraking >= 0.0f && EndBrakingDistance > KINDA_SMALL_NUMBER)
    {
        const float DistanceScale = FMath::Clamp(DistanceForBraking / EndBrakingDistance, 0.1f, 1.0f);
        TargetSpeed *= DistanceScale;
    }

    const float CurrentSpeed = GetForwardSpeedKPH();
    float Throttle = 0.0f;
    float Brake = 0.0f;

    if (CurrentSpeed > TargetSpeed + 1.0f)
    {
        Brake = FMath::Clamp((CurrentSpeed - TargetSpeed) * SpeedControlGain, 0.0f, MaximumBrakeInput);
    }
    else if (CurrentSpeed < TargetSpeed - 0.25f)
    {
        const float RawThrottle = (TargetSpeed - CurrentSpeed) * SpeedControlGain;
        Throttle = FMath::Clamp(FMath::Max(0.12f, RawThrottle), 0.0f, MaximumThrottleInput);
    }

    if (ObstacleSpeedScale <= 0.15f)
    {
        Throttle = 0.0f;
        Brake = FMath::Max(Brake, 0.65f);
    }

    if (bReverseGear)
    {
        VehicleMovement->SetUseAutomaticGears(false);
        VehicleMovement->SetTargetGear(-1, true);
    }
    else
    {
        VehicleMovement->SetUseAutomaticGears(true);
    }

    VehicleMovement->SetHandbrakeInput(false);
    VehicleMovement->SetSteeringInput(Steering);
    VehicleMovement->SetThrottleInput(Throttle);
    VehicleMovement->SetBrakeInput(Brake);

    LastSteeringCommand = Steering;
    LastThrottleCommand = Throttle;
    LastBrakeCommand = Brake;
}

void URenegadeVehicleDriverComponent::CalculateObstacleAvoidance(const bool bReverseProbe, float& OutSteeringBias, float& OutSpeedScale) const
{
    OutSteeringBias = 0.0f;
    OutSpeedScale = 1.0f;

    if (!bEnableObstacleAvoidance || !GetWorld() || !GetOwner())
    {
        return;
    }

    const float CenterClearance = ProbeObstacleAtYaw(0.0f, bReverseProbe);
    const float LeftClearance = ProbeObstacleAtYaw(-SideProbeAngleDegrees, bReverseProbe);
    const float RightClearance = ProbeObstacleAtYaw(SideProbeAngleDegrees, bReverseProbe);

    const float CenterThreat = 1.0f - FMath::Clamp(CenterClearance / ObstacleProbeDistance, 0.0f, 1.0f);
    const float LeftThreat = 1.0f - FMath::Clamp(LeftClearance / ObstacleProbeDistance, 0.0f, 1.0f);
    const float RightThreat = 1.0f - FMath::Clamp(RightClearance / ObstacleProbeDistance, 0.0f, 1.0f);

    OutSteeringBias = FMath::Clamp((LeftThreat - RightThreat) * ObstacleSteeringWeight, -1.0f, 1.0f);

    if (CenterThreat > 0.0f)
    {
        if (FMath::IsNearlyEqual(LeftThreat, RightThreat, 0.05f))
        {
            OutSteeringBias += static_cast<float>(CombatOrbitSign) * CenterThreat * 0.65f;
        }

        OutSpeedScale = FMath::Clamp(1.0f - CenterThreat * 0.9f, 0.0f, 1.0f);
    }

    if (bReverseProbe)
    {
        OutSteeringBias *= -1.0f;
    }

    OutSteeringBias = FMath::Clamp(OutSteeringBias, -1.0f, 1.0f);
}

float URenegadeVehicleDriverComponent::ProbeObstacleAtYaw(const float YawDegrees, const bool bReverseProbe) const
{
    if (!GetWorld() || !GetOwner())
    {
        return ObstacleProbeDistance;
    }

    FVector BoundsOrigin = GetOwner()->GetActorLocation();
    FVector BoundsExtent = FVector(150.0f, 100.0f, 75.0f);
    GetOwner()->GetActorBounds(true, BoundsOrigin, BoundsExtent);

    const FVector BaseDirection = (bReverseProbe ? -GetOwner()->GetActorForwardVector() : GetOwner()->GetActorForwardVector()).GetSafeNormal2D();
    const float BodyHalfLength = FMath::Max(BoundsExtent.X, BoundsExtent.Y);
    const float EffectiveRadius = FMath::Min(ObstacleProbeRadius, FMath::Max(25.0f, BoundsExtent.Z * 0.45f));
    const FVector Start = BoundsOrigin + BaseDirection * (BodyHalfLength + EffectiveRadius + 25.0f) + FVector::UpVector * ObstacleProbeHeight;
    const FVector ProbeDirection = BaseDirection.RotateAngleAxis(YawDegrees, FVector::UpVector).GetSafeNormal();
    const FVector End = Start + ProbeDirection * ObstacleProbeDistance;

    FCollisionQueryParams QueryParams(FName(TEXT("RenegadeVehicleObstacleProbe")), false, GetOwner());
    QueryParams.AddIgnoredActor(GetOwner());

    FHitResult Hit;
    const bool bHit = GetWorld()->SweepSingleByChannel(
        Hit,
        Start,
        End,
        FQuat::Identity,
        static_cast<ECollisionChannel>(ObstacleTraceChannel.GetValue()),
        FCollisionShape::MakeSphere(EffectiveRadius),
        QueryParams,
        FCollisionResponseParams::DefaultResponseParam);

    return bHit ? FMath::Max(0.0f, Hit.Distance) : ObstacleProbeDistance;
}
