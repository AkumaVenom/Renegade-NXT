#include "RenegadeHarvesterComponent.h"

#include "GameFramework/Actor.h"
#include "Net/UnrealNetwork.h"
#include "RenegadeHarvestPoint.h"
#include "RenegadeRefineryDock.h"
#include "RenegadeVehicleDriverComponent.h"
#include "RenegadeVehicleSplinePath.h"

URenegadeHarvesterComponent::URenegadeHarvesterComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    SetIsReplicatedByDefault(true);
}

void URenegadeHarvesterComponent::BeginPlay()
{
    Super::BeginPlay();

    if (ResolveDriverComponent())
    {
        DriverComponent->OnRouteCompleted.AddDynamic(this, &URenegadeHarvesterComponent::HandleRouteCompleted);
        DriverComponent->OnWorldTargetReached.AddDynamic(this, &URenegadeHarvesterComponent::HandleWorldTargetReached);
    }

    if (GetOwner() && GetOwner()->HasAuthority() && bAutoStart)
    {
        StartHarvestCycle();
    }
}

void URenegadeHarvesterComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (IsValid(HarvestPoint) && GetOwner() && GetOwner()->HasAuthority())
    {
        HarvestPoint->ReleaseReservation(GetOwner());
    }

    if (DriverComponent)
    {
        DriverComponent->OnRouteCompleted.RemoveDynamic(this, &URenegadeHarvesterComponent::HandleRouteCompleted);
        DriverComponent->OnWorldTargetReached.RemoveDynamic(this, &URenegadeHarvesterComponent::HandleWorldTargetReached);
    }

    Super::EndPlay(EndPlayReason);
}

void URenegadeHarvesterComponent::TickComponent(
    const float DeltaTime,
    const ELevelTick TickType,
    FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (!GetOwner() || !GetOwner()->HasAuthority())
    {
        return;
    }

    switch (HarvesterState)
    {
        case ERenegadeHarvesterState::WaitingForHarvestPoint:
            UpdateWaitingForHarvestPoint(DeltaTime);
            break;

        case ERenegadeHarvesterState::Harvesting:
            UpdateHarvesting(DeltaTime);
            break;

        case ERenegadeHarvesterState::Unloading:
            UpdateUnloading(DeltaTime);
            break;

        case ERenegadeHarvesterState::WaitingAtRefinery:
            UpdateWaitingAtRefinery(DeltaTime);
            break;

        default:
            break;
    }
}

void URenegadeHarvesterComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(URenegadeHarvesterComponent, HarvesterState);
    DOREPLIFETIME(URenegadeHarvesterComponent, CurrentCargo);
}

bool URenegadeHarvesterComponent::StartHarvestCycle()
{
    if (!GetOwner() || !GetOwner()->HasAuthority())
    {
        return false;
    }

    if (!ResolveDriverComponent() || !ValidateConfiguration(true))
    {
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return false;
    }

    if (DriverComponent->IsInCombatMovement())
    {
        OnHarvesterFault.Broadcast(TEXT("The harvest cycle cannot start while the vehicle driver is in combat movement."));
        return false;
    }

    if (!HarvestPoint->IsTeamAllowed(DriverComponent->TeamId))
    {
        OnHarvesterFault.Broadcast(TEXT("The assigned harvest point does not allow this harvester's Team Id."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return false;
    }

    if (!RefineryDock->AcceptsTeam(DriverComponent->TeamId))
    {
        OnHarvesterFault.Broadcast(TEXT("The assigned refinery dock does not accept this harvester's Team Id."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return false;
    }

    HarvestPoint->ReleaseReservation(GetOwner());
    PendingDeliveryAmount = 0.0f;
    SetHarvesterState(ERenegadeHarvesterState::DrivingToHarvest);
    OnHarvestCycleStarted.Broadcast();

    if (!DriverComponent->StartFollowing(OutboundPath, true, ERenegadeVehicleRouteDirection::Forward))
    {
        OnHarvesterFault.Broadcast(TEXT("The harvester could not start its outbound route."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return false;
    }

    return true;
}

void URenegadeHarvesterComponent::StopHarvestCycle(const bool bApplyBrake)
{
    if (!GetOwner() || !GetOwner()->HasAuthority())
    {
        return;
    }

    if (IsValid(HarvestPoint))
    {
        HarvestPoint->ReleaseReservation(GetOwner());
    }

    if (DriverComponent)
    {
        DriverComponent->StopDriving(false, bApplyBrake);
    }

    SetHarvesterState(ERenegadeHarvesterState::Idle);
}

void URenegadeHarvesterComponent::SetCurrentCargo(const float NewCargo)
{
    if (!GetOwner() || !GetOwner()->HasAuthority())
    {
        return;
    }

    const float ClampedCargo = FMath::Clamp(NewCargo, 0.0f, FMath::Max(1.0f, CargoCapacity));
    if (!FMath::IsNearlyEqual(CurrentCargo, ClampedCargo))
    {
        CurrentCargo = ClampedCargo;
        OnCargoChanged.Broadcast(CurrentCargo, CargoCapacity);
    }
}

bool URenegadeHarvesterComponent::IsCargoFull() const
{
    return CurrentCargo >= FMath::Max(1.0f, CargoCapacity) - KINDA_SMALL_NUMBER;
}

void URenegadeHarvesterComponent::SetHarvesterState(const ERenegadeHarvesterState NewState)
{
    if (HarvesterState == NewState)
    {
        return;
    }

    const ERenegadeHarvesterState PreviousState = HarvesterState;
    HarvesterState = NewState;
    OnHarvesterStateChanged.Broadcast(PreviousState, NewState);
}

bool URenegadeHarvesterComponent::ResolveDriverComponent()
{
    DriverComponent = GetOwner() ? GetOwner()->FindComponentByClass<URenegadeVehicleDriverComponent>() : nullptr;
    return DriverComponent != nullptr;
}

bool URenegadeHarvesterComponent::ValidateConfiguration(const bool bBroadcastFault)
{
    FString Fault;

    if (!DriverComponent)
    {
        Fault = TEXT("RenegadeHarvesterComponent requires RenegadeVehicleDriverComponent on the same vehicle Blueprint.");
    }
    else if (!IsValid(OutboundPath))
    {
        Fault = TEXT("No outbound vehicle spline path is assigned.");
    }
    else if (OutboundPath->bClosedLoop)
    {
        Fault = TEXT("The harvester outbound path must be an open spline so route completion can start harvesting.");
    }
    else if (!IsValid(HarvestPoint))
    {
        Fault = TEXT("No RenegadeHarvestPoint is assigned.");
    }
    else if (!IsValid(RefineryDock))
    {
        Fault = TEXT("No RenegadeRefineryDock is assigned.");
    }
    else if (IsValid(ReturnPath) && ReturnPath->bClosedLoop)
    {
        Fault = TEXT("The harvester return path must be an open spline so route completion can start unloading.");
    }
    else if (!IsValid(ReturnPath) && !bReverseOutboundPathWhenReturnPathMissing)
    {
        Fault = TEXT("No return path is assigned and reverse-outbound fallback is disabled.");
    }
    else if (!IsValid(ReturnPath) && bReverseOutboundPathWhenReturnPathMissing && !OutboundPath->bAllowReverseTravel)
    {
        Fault = TEXT("The outbound path does not allow reverse travel, so it cannot be used as the refinery return route.");
    }

    if (!Fault.IsEmpty() && bBroadcastFault)
    {
        OnHarvesterFault.Broadcast(Fault);
    }

    return Fault.IsEmpty();
}

void URenegadeHarvesterComponent::BeginHarvesting()
{
    if (!IsValid(HarvestPoint) || !GetOwner())
    {
        OnHarvesterFault.Broadcast(TEXT("The harvest point became invalid."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return;
    }

    if (HarvestPoint->TryReserve(GetOwner()))
    {
        SetHarvesterState(ERenegadeHarvesterState::Harvesting);
        ReservationRetryCountdown = 0.0f;
    }
    else
    {
        ReservationRetryCountdown = 0.0f;
        SetHarvesterState(ERenegadeHarvesterState::WaitingForHarvestPoint);
    }
}

void URenegadeHarvesterComponent::BeginReturnToRefinery()
{
    if (!DriverComponent || !IsValid(OutboundPath))
    {
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return;
    }

    if (IsValid(HarvestPoint) && GetOwner())
    {
        HarvestPoint->ReleaseReservation(GetOwner());
    }

    SetHarvesterState(ERenegadeHarvesterState::DrivingToRefinery);

    const bool bStarted = IsValid(ReturnPath)
        ? DriverComponent->StartFollowing(ReturnPath, true, ERenegadeVehicleRouteDirection::Forward, false)
        : DriverComponent->StartFollowing(OutboundPath, true, ERenegadeVehicleRouteDirection::Reverse, false);

    if (!bStarted)
    {
        OnHarvesterFault.Broadcast(TEXT("The harvester could not start its refinery return route."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
    }
}

void URenegadeHarvesterComponent::BeginUnloading()
{
    if (!IsValid(RefineryDock))
    {
        OnHarvesterFault.Broadcast(TEXT("The refinery dock became invalid."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return;
    }

    PendingDeliveryAmount = 0.0f;
    SetHarvesterState(ERenegadeHarvesterState::Unloading);
}

void URenegadeHarvesterComponent::RestartAfterRefinery()
{
    if (!bRepeatCycle)
    {
        SetHarvesterState(ERenegadeHarvesterState::Idle);
        return;
    }

    RestartCountdown = RestartDelayAtRefinery;
    SetHarvesterState(ERenegadeHarvesterState::WaitingAtRefinery);
}

void URenegadeHarvesterComponent::UpdateHarvesting(const float DeltaTime)
{
    if (IsWorkPausedForCombat())
    {
        return;
    }

    if (!IsValid(HarvestPoint))
    {
        OnHarvesterFault.Broadcast(TEXT("The harvest point became invalid while harvesting."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return;
    }

    const float RemainingCapacity = FMath::Max(0.0f, CargoCapacity - CurrentCargo);
    if (RemainingCapacity <= KINDA_SMALL_NUMBER)
    {
        BeginReturnToRefinery();
        return;
    }

    const float Requested = FMath::Min(
        RemainingCapacity,
        HarvestRatePerSecond * HarvestPoint->ExtractionRateMultiplier * DeltaTime);

    const float Extracted = HarvestPoint->ExtractResource(Requested);
    if (Extracted > 0.0f)
    {
        SetCurrentCargo(CurrentCargo + Extracted);
    }

    if (IsCargoFull() || Extracted <= KINDA_SMALL_NUMBER)
    {
        BeginReturnToRefinery();
    }
}

void URenegadeHarvesterComponent::UpdateWaitingForHarvestPoint(const float DeltaTime)
{
    if (IsWorkPausedForCombat())
    {
        return;
    }

    ReservationRetryCountdown -= DeltaTime;
    if (ReservationRetryCountdown > 0.0f)
    {
        return;
    }

    ReservationRetryCountdown = FMath::Max(0.1f, ReservationRetryInterval);
    BeginHarvesting();
}

void URenegadeHarvesterComponent::UpdateUnloading(const float DeltaTime)
{
    if (IsWorkPausedForCombat())
    {
        return;
    }

    if (!IsValid(RefineryDock))
    {
        OnHarvesterFault.Broadcast(TEXT("The refinery dock became invalid while unloading."));
        SetHarvesterState(ERenegadeHarvesterState::Disabled);
        return;
    }

    const float UnloadRate = UnloadRatePerSecond * RefineryDock->UnloadRateMultiplier;
    const float Unloaded = FMath::Min(CurrentCargo, UnloadRate * DeltaTime);
    if (Unloaded > 0.0f)
    {
        PendingDeliveryAmount += Unloaded;
        SetCurrentCargo(CurrentCargo - Unloaded);
    }

    if (CurrentCargo <= KINDA_SMALL_NUMBER)
    {
        const float DeliveredAmount = PendingDeliveryAmount;
        PendingDeliveryAmount = 0.0f;

        RefineryDock->ReceiveDelivery(GetOwner(), DeliveredAmount);
        OnCargoDelivered.Broadcast(DeliveredAmount);
        OnHarvestCycleCompleted.Broadcast();
        RestartAfterRefinery();
    }
}

void URenegadeHarvesterComponent::UpdateWaitingAtRefinery(const float DeltaTime)
{
    if (IsWorkPausedForCombat())
    {
        return;
    }

    RestartCountdown -= DeltaTime;
    if (RestartCountdown <= 0.0f)
    {
        StartHarvestCycle();
    }
}

bool URenegadeHarvesterComponent::IsWorkPausedForCombat() const
{
    return bPauseWorkDuringCombatMovement && DriverComponent && DriverComponent->IsInCombatMovement();
}

void URenegadeHarvesterComponent::HandleRouteCompleted(ARenegadeVehicleSplinePath* CompletedPath)
{
    if (!GetOwner() || !GetOwner()->HasAuthority() || !DriverComponent)
    {
        return;
    }

    if (HarvesterState == ERenegadeHarvesterState::DrivingToHarvest && CompletedPath == OutboundPath)
    {
        const float InteractionRadius = IsValid(HarvestPoint) ? HarvestPoint->GetInteractionRadius() : 500.0f;
        const float Distance = IsValid(HarvestPoint)
            ? FVector::Dist2D(GetOwner()->GetActorLocation(), HarvestPoint->GetActorLocation())
            : 0.0f;

        if (IsValid(HarvestPoint) && Distance > InteractionRadius)
        {
            SetHarvesterState(ERenegadeHarvesterState::ApproachingHarvest);
            if (!DriverComponent->SetWorldMoveTarget(HarvestPoint->GetActorLocation(), DockApproachSpeedKPH, InteractionRadius * 0.8f))
            {
                OnHarvesterFault.Broadcast(TEXT("The harvester could not approach the harvest point."));
                SetHarvesterState(ERenegadeHarvesterState::Disabled);
            }
        }
        else
        {
            BeginHarvesting();
        }
        return;
    }

    if (HarvesterState == ERenegadeHarvesterState::DrivingToRefinery &&
        (CompletedPath == ReturnPath || (!IsValid(ReturnPath) && CompletedPath == OutboundPath)))
    {
        const float DockingRadius = IsValid(RefineryDock) ? RefineryDock->GetDockingRadius() : 500.0f;
        const float Distance = IsValid(RefineryDock)
            ? FVector::Dist2D(GetOwner()->GetActorLocation(), RefineryDock->GetActorLocation())
            : 0.0f;

        if (IsValid(RefineryDock) && Distance > DockingRadius)
        {
            SetHarvesterState(ERenegadeHarvesterState::ApproachingRefinery);
            if (!DriverComponent->SetWorldMoveTarget(RefineryDock->GetActorLocation(), DockApproachSpeedKPH, DockingRadius * 0.8f))
            {
                OnHarvesterFault.Broadcast(TEXT("The harvester could not approach the refinery dock."));
                SetHarvesterState(ERenegadeHarvesterState::Disabled);
            }
        }
        else
        {
            BeginUnloading();
        }
    }
}

void URenegadeHarvesterComponent::HandleWorldTargetReached()
{
    if (!GetOwner() || !GetOwner()->HasAuthority())
    {
        return;
    }

    if (HarvesterState == ERenegadeHarvesterState::ApproachingHarvest)
    {
        BeginHarvesting();
    }
    else if (HarvesterState == ERenegadeHarvesterState::ApproachingRefinery)
    {
        BeginUnloading();
    }
}
