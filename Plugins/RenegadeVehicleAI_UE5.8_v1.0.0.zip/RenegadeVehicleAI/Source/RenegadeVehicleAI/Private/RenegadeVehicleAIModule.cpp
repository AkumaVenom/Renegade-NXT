#include "Modules/ModuleManager.h"

class FRenegadeVehicleAIModule final : public IModuleInterface
{
};

IMPLEMENT_MODULE(FRenegadeVehicleAIModule, RenegadeVehicleAI)
