#include "RenegadeRefineryDock.h"

#include "Components/SceneComponent.h"
#include "Components/SphereComponent.h"

ARenegadeRefineryDock::ARenegadeRefineryDock()
{
    PrimaryActorTick.bCanEverTick = false;

    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SetRootComponent(SceneRoot);

    DockingVolume = CreateDefaultSubobject<USphereComponent>(TEXT("DockingVolume"));
    DockingVolume->SetupAttachment(SceneRoot);
    DockingVolume->SetSphereRadius(700.0f);
    DockingVolume->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

bool ARenegadeRefineryDock::AcceptsTeam(const int32 HarvesterTeamId) const
{
    return TeamId == INDEX_NONE || TeamId == HarvesterTeamId;
}

void ARenegadeRefineryDock::ReceiveDelivery(AActor* Harvester, const float DeliveredAmount)
{
    if (!HasAuthority() || !IsValid(Harvester) || DeliveredAmount <= 0.0f)
    {
        return;
    }

    OnDeliveryReceived.Broadcast(Harvester, DeliveredAmount);
}

float ARenegadeRefineryDock::GetDockingRadius() const
{
    return DockingVolume ? DockingVolume->GetScaledSphereRadius() : 700.0f;
}
