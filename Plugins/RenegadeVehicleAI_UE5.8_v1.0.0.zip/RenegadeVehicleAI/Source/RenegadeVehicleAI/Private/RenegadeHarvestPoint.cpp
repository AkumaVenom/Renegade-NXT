#include "RenegadeHarvestPoint.h"

#include "Components/SceneComponent.h"
#include "Components/SphereComponent.h"
#include "Net/UnrealNetwork.h"

ARenegadeHarvestPoint::ARenegadeHarvestPoint()
{
    PrimaryActorTick.bCanEverTick = false;
    bReplicates = true;

    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SetRootComponent(SceneRoot);

    InteractionVolume = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionVolume"));
    InteractionVolume->SetupAttachment(SceneRoot);
    InteractionVolume->SetSphereRadius(650.0f);
    InteractionVolume->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void ARenegadeHarvestPoint::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(ARenegadeHarvestPoint, AvailableResource);
    DOREPLIFETIME(ARenegadeHarvestPoint, ReservedBy);
}

bool ARenegadeHarvestPoint::IsTeamAllowed(const int32 TeamId) const
{
    return AllowedTeamIds.IsEmpty() || AllowedTeamIds.Contains(TeamId);
}

bool ARenegadeHarvestPoint::IsAvailableFor(AActor* Harvester) const
{
    if (!bInfiniteResource && AvailableResource <= KINDA_SMALL_NUMBER)
    {
        return false;
    }

    return !bExclusiveReservation || !IsValid(ReservedBy) || (IsValid(Harvester) && ReservedBy == Harvester);
}

bool ARenegadeHarvestPoint::TryReserve(AActor* Harvester)
{
    if (!HasAuthority() || !IsValid(Harvester) || !IsAvailableFor(Harvester))
    {
        return false;
    }

    if (ReservedBy != Harvester)
    {
        ReservedBy = Harvester;
        OnReserved.Broadcast(Harvester);
    }

    return true;
}

void ARenegadeHarvestPoint::ReleaseReservation(AActor* Harvester)
{
    if (!HasAuthority() || ReservedBy != Harvester)
    {
        return;
    }

    AActor* ReleasedHarvester = ReservedBy;
    ReservedBy = nullptr;
    OnReservationReleased.Broadcast(ReleasedHarvester);
}

float ARenegadeHarvestPoint::ExtractResource(const float RequestedAmount)
{
    if (!HasAuthority() || RequestedAmount <= 0.0f)
    {
        return 0.0f;
    }

    if (bInfiniteResource)
    {
        return RequestedAmount;
    }

    const float Extracted = FMath::Min(RequestedAmount, AvailableResource);
    AvailableResource = FMath::Max(0.0f, AvailableResource - Extracted);

    if (AvailableResource <= KINDA_SMALL_NUMBER)
    {
        OnDepleted.Broadcast();
    }

    return Extracted;
}

float ARenegadeHarvestPoint::GetInteractionRadius() const
{
    return InteractionVolume ? InteractionVolume->GetScaledSphereRadius() : 650.0f;
}
