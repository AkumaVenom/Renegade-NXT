# Renegade Vehicle AI — UE 5.8

A source runtime plugin for **Renegade NXT** that makes Chaos vehicles physically drive along authored spline routes without attaching or teleporting them to the spline.

The plugin is designed as a companion to the existing:

- `RenegadeSplineAI` infantry route plugin
- `RenegadeSoldierCombat` combat plugin

It deliberately follows the same project conventions: generic integer `Team Id`, named route groups, server-authoritative AI, explicit combat hand-off, and route reacquisition from the unit's current location.

## Main features

- Works with multiple unrelated Chaos vehicle Blueprints.
- Automatically discovers `UChaosVehicleMovementComponent` on the owning vehicle.
- Pure-pursuit style spline driving using throttle, steering, brake, and gear inputs.
- Vehicles remain normal physics vehicles; they are never attached to the spline.
- Forward and reverse **spline traversal**, with an independent optional reverse-gear mode.
- Open routes and closed-loop patrol routes.
- Per-vehicle lane offsets so convoys do not all drive on the exact spline centre.
- Speed limiting, turn-speed reduction, and end-of-route braking.
- Three-feeler sphere-sweep obstacle avoidance.
- Automatic reverse/forward stuck recovery.
- Combat movement modes that interrupt route travel and move around an enemy instead of driving straight past it.
- Automatic route reacquisition after combat using the same `Set Combat Active` pattern as `RenegadeSplineAI`.
- Dedicated harvester state machine with resource collection, cargo, refinery unloading, reservations, and repeating cycles.
- Separate outbound and refinery-return splines, or automatic reverse-direction traversal of the outbound spline when no return spline is assigned.
- Multiplayer-safe authority model with replicated route state, combat target, harvester state, and cargo.
- Blueprint delegates for weapon firing requests, route completion, cargo delivery, faults, and state changes.

## Installation

1. Close Unreal Editor.
2. Copy the complete `RenegadeVehicleAI` folder into:

   `YourProject/Plugins/RenegadeVehicleAI`

3. Confirm the built-in **Chaos Vehicles** plugin is enabled.
4. Right-click `RenegadeNXT.uproject` and generate Visual Studio project files.
5. Build the **Development Editor / Win64** target.
6. Open the project and enable **Renegade Vehicle AI** under **Edit > Plugins > AI** if required.

This package contains source code. It was authored against the public Unreal Engine 5.8 API. It cannot be binary-compiled in this environment because your local UE 5.8.1 engine installation and project vehicle classes are required.

# Standard combat vehicle setup

## 1. Add the driver component

Open every vehicle Blueprint that should use route AI, for example:

- GDI Humvee
- GDI APC
- GDI Medium Tank
- GDI MRLS
- Nod Buggy
- Nod APC
- Nod Light Tank
- Nod Artillery
- either faction's Harvester

Add:

`RenegadeVehicleDriverComponent`

The same component works on all of them. The owning actor only needs a valid `UChaosVehicleMovementComponent`.

Recommended initial values:

| Property | Starting value |
|---|---:|
| Cruise Speed KPH | 35–45 |
| Turn Speed KPH | 15–22 |
| Look Ahead Distance | 800–1200 cm |
| Minimum Look Ahead Distance | 300–450 cm |
| Route End Tolerance | 220–350 cm |
| End Braking Distance | 1000–1800 cm |
| Obstacle Probe Distance | 1000–1600 cm |
| Obstacle Probe Radius | 100–180 cm |
| Stuck Detection Time | 2.5–4.0 s |

Heavy tanks should normally use a lower cruise speed and larger look-ahead distance than buggies or Humvees.

## 2. Place a route

Place `RenegadeVehicleSplinePath` in the level and edit `RouteSpline` so it follows the centre of the road or terrain lane.

Useful properties:

- `Route Group`: `GDI_Vehicle_Assault`, `Nod_Vehicle_Assault`, `GDI_Harvester_Outbound`, and similar names.
- `Route Purpose`: General, Combat, Patrol, Harvester Outbound, Harvester Return, or Refinery Approach.
- `Allowed Team Ids`: leave empty for any team or enter the same team integers used by the soldier plugins.
- `Speed Limit KPH`: zero uses the vehicle component's cruise speed.
- `Closed Loop`: use only for patrol circuits.
- `Allow Reverse Travel`: required when a harvester will traverse the same spline back toward its start.

The spline is driving guidance, not a transform rail. Keep it far enough from walls, rocks, steep edges, and building corners for the full vehicle width and turning radius.

## 3. Start following

You can assign `Auto Start Path` and enable `Auto Start`, or call this from server-owned Blueprint logic:

```text
VehicleDriver.Start Following Vehicle Path(
    Path = SelectedVehiclePath,
    Reacquire From Current Location = true,
    Direction = Spline Forward,
    Use Reverse Gear = false)
```

For automatic route lookup:

```text
Path = Find Nearest Compatible Vehicle Path(
    World Location = Vehicle Location,
    Team Id = Vehicle Team Id,
    Required Route Group = GDI_Vehicle_Assault)
```

# Combat integration

The route driver does not decide which actor is an enemy. Your vehicle perception, weapon, turret, or Renegade combat logic remains responsible for selecting the current target.

This prevents duplicate target systems and follows the same ownership rule as `RenegadeSplineAI`.

## Enemy acquired

Call this before the weapon or combat system begins its attack:

```text
VehicleDriver.Set Combat Active(
    Combat Active = true,
    New Combat Target = Current Enemy)
```

The route is preserved, but spline driving stops. The default `Dynamic Standoff` mode then:

- approaches when too far away;
- drives away and to the side when too close;
- chooses an orbit/standoff point when inside the useful combat range;
- continues obstacle avoidance and stuck recovery;
- broadcasts `On Fire Requested` with the current target and aim location.

This prevents hostile vehicles from blindly driving past enemies while their weapons fire.

## Enemy killed, lost, or abandoned

```text
VehicleDriver.Set Combat Active(
    Combat Active = false,
    New Combat Target = None,
    Resume Delay Override = -1)
```

After `Default Combat Resume Delay`, the driver finds the closest point on its assigned route, applies `Maximum Resume Backtrack`, and continues from its current world position.

## Combat manoeuvre choices

- **Dynamic Standoff**: recommended default. Approaches, escapes, or orbits according to range.
- **Orbit Target**: continually chooses a point around the target.
- **Advance And Hold**: approaches the preferred range and stops near that position.
- **Hold Position**: brakes in place while `On Fire Requested` continues.

For a tank with a rotating turret, `Dynamic Standoff` or `Orbit Target` is usually best. For artillery or an MRLS, use `Advance And Hold` with a longer preferred combat distance.

## Weapon hookup

Bind `On Fire Requested` to your existing vehicle weapon logic. The event supplies:

- `Target Actor`
- `Aim Location`

The driver does not spawn projectiles or apply damage because every Renegade NXT vehicle can have different barrels, turrets, weapon sockets, fire rates, and projectile classes.

# Harvester setup

A harvester Blueprint needs both:

- `RenegadeVehicleDriverComponent`
- `RenegadeHarvesterComponent`

## Level actors

Place:

1. `RenegadeHarvestPoint` in the Tiberium field.
2. `RenegadeRefineryDock` at the refinery unloading position.
3. A `RenegadeVehicleSplinePath` from refinery to field.
4. A separate `RenegadeVehicleSplinePath` from field to refinery.

Recommended route purposes:

- outbound route: `Harvester Outbound`
- return route: `Harvester Return`

The end of the outbound spline should be inside or close to the Harvest Point interaction sphere. The end of the return spline should be inside or close to the Refinery Dock sphere.

## Harvester component assignments

Assign:

- `Outbound Path`
- `Return Path`
- `Harvest Point`
- `Refinery Dock`
- `Cargo Capacity`
- `Harvest Rate Per Second`
- `Unload Rate Per Second`

Enable `Auto Start` for a completely automatic repeating cycle.

## One-spline alternative

To drive back along the same authored route:

- leave `Return Path` empty;
- enable `Reverse Outbound Path When Return Path Missing`;
- ensure the outbound path has `Allow Reverse Travel` enabled.

The driver traverses the outbound spline from end to start while normally using forward gear, allowing the harvester to turn around and drive back naturally. `Use Reverse Gear` is a separate advanced option for short reversing routes or docking.

## Harvester cycle

```text
Driving To Harvest
→ Approaching Harvest Point
→ Waiting For Reservation if occupied
→ Harvesting
→ Driving To Refinery
→ Approaching Refinery Dock
→ Unloading
→ Waiting At Refinery
→ repeat
```

Harvest points can be infinite or finite. Exclusive reservation prevents multiple harvesters from occupying the same collection point.

## Economy hookup

Bind either of these delegates to the Renegade NXT team-credit system:

- `RenegadeHarvesterComponent.On Cargo Delivered`
- `RenegadeRefineryDock.On Delivery Received`

The delivered float is intentionally generic so your project can convert one cargo unit into the correct GDI or Nod credit value.

# Compatibility with the existing plugins

This plugin does not replace or modify `RenegadeSplineAI` or `RenegadeSoldierCombat`.

Compatibility is maintained through matching conventions:

- same generic integer `Team Id` model;
- same route-group concept;
- same explicit `Set Combat Active(true/false)` hand-off;
- server-authoritative movement commands;
- route state and progress replicated for observation;
- combat target selection remains owned by the combat system;
- route movement resumes from the actor's current location after combat.

Do not add `RenegadeSplineFollowerComponent` to a Chaos vehicle. Infantry uses NavMesh movement through `RenegadeSplineAI`; vehicles use physics inputs through `RenegadeVehicleDriverComponent`.

# Multiplayer notes

Only the server applies AI throttle, brake, steering, and gear commands. Chaos vehicle physics and actor replication remain responsible for client movement presentation.

Call route changes, combat state changes, and harvester-cycle commands from server-owned logic. A client UI request should be passed through a validated server RPC first.

# Troubleshooting

## Vehicle does not move

- Confirm the Blueprint contains a Chaos vehicle movement component.
- Confirm Chaos Vehicles is enabled.
- Confirm the vehicle has working wheels, engine torque, transmission, and physics asset before adding AI.
- Check `On Driver Fault`.
- Confirm the call runs on the server.
- Leave `Allow Inputs Without Controller` enabled unless the vehicle is always possessed.

## Vehicle steers the wrong way

- Confirm the vehicle mesh and movement setup use Unreal's expected forward axis.
- Confirm the vehicle Blueprint itself drives correctly with normal player throttle and steering input.
- Reduce `Steering Gain` if it oscillates.
- Increase `Look Ahead Distance` for long vehicles or high speed.

## Vehicle cuts corners

- Add more spline points around the bend.
- Lower cruise speed.
- Increase look-ahead only slightly; excessive look-ahead can cut a sharp corner.
- Increase road clearance from obstacles.

## Vehicle keeps stopping near scenery

- Use a dedicated collision trace channel for vehicle obstacles.
- Make decorative grass and harmless effects ignore that channel.
- Reduce `Obstacle Probe Radius` if the vehicle has generous road clearance.

## Vehicle fights the route during combat

Call `Set Combat Active(true, Enemy)` before issuing combat movement. Do not run another repeating throttle/steering system at the same time as the driver component.

## Harvester reaches the route end but does not harvest

- Assign the correct Harvest Point.
- Move the outbound spline endpoint into the interaction sphere.
- Confirm the Harvest Point allows the harvester's Team Id.
- Check whether another harvester owns the exclusive reservation.

## Harvester will not return on the same route

- Leave `Return Path` empty.
- Enable `Reverse Outbound Path When Return Path Missing`.
- Enable `Allow Reverse Travel` on the outbound path. This reverses spline direction, not the transmission gear.

# Principal Blueprint API

## `RenegadeVehicleDriverComponent`

- `Start Following Vehicle Path`
- `Stop Driving`
- `Resume Following`
- `Set Combat Active`
- `Set World Move Target`
- `Clear World Move Target`
- `Set Driving Enabled`
- `Get Forward Speed KPH`
- `Is In Combat Movement`

## `RenegadeHarvesterComponent`

- `Start Harvest Cycle`
- `Stop Harvest Cycle`
- `Set Current Cargo`
- `Is Cargo Full`

## Blueprint lookup library

- `Find Nearest Compatible Vehicle Path`
- `Find Nearest Available Harvest Point`
- `Get Vehicle Driver Component`
- `Get Harvester Component`
