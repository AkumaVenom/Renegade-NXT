# Blueprint quick reference

## Any AI vehicle

1. Add `RenegadeVehicleDriverComponent`.
2. Set its `Team Id` to the same integer used by Renegade NXT combat.
3. Place `RenegadeVehicleSplinePath` in the level.
4. Call `Start Following Vehicle Path` on the server. `Direction` controls spline direction; leave `Use Reverse Gear` false for normal driving.
5. On target acquired, call `Set Combat Active(true, Target)`.
6. On target cleared, call `Set Combat Active(false)`.
7. Bind `On Fire Requested` to the vehicle's existing weapon event.

## Harvester

1. Add `RenegadeVehicleDriverComponent`.
2. Add `RenegadeHarvesterComponent`.
3. Place one `RenegadeHarvestPoint` and one `RenegadeRefineryDock`.
4. Place outbound and return `RenegadeVehicleSplinePath` actors.
5. Assign all four actors on the Harvester component.
6. Enable `Auto Start`.
7. Bind `On Cargo Delivered` to the team economy Blueprint.
